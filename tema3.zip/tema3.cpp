#include <iostream>
#include <fstream>
#include <mpi.h>
#include <pthread.h>
#include <vector>
#include <utility>
#include <string.h>
#include <cstdlib>
// #include <stdio.h>
// #include <stdlib.h>
using namespace std;

#define TRACKER_RANK 0
#define MAX_FILES 10
#define MAX_FILENAME 15
#define HASH_SIZE 32
#define MAX_CHUNKS 100

#define INIT_TAG 0
#define FILE_INFO_TAG 1
#define SWARM_INFO_TAG 2
#define DOWNLOAD_DONE_TAG 3
#define UPLOAD_TH_TAG 4
#define ACK_TAG 5
#define UPDATE_TAG 6



typedef struct {
    char name[MAX_FILENAME];
    vector<string> segments;
}file;

typedef struct {
    char name[MAX_FILENAME];
    vector<string> wanted_segs;
    map<int, vector<string>> swarm;
}wanted_file;

typedef struct {
    vector<file> owned_files;
    vector<wanted_file> wanted_files;
}peer_info;


peer_info info;
map<string, pair<vector<string>, map<int, vector<string>>>> db;
vector<pair<string, int>> received_segs;


void get_file_info() {
    MPI_Status status;
    for (int i = 0; i < info.wanted_files.size(); i++) {
        int name_len = strlen(info.wanted_files[i].name);
        MPI_Send(nullptr, 0, MPI_INT, TRACKER_RANK, FILE_INFO_TAG, MPI_COMM_WORLD);
        MPI_Send(&name_len, 1, MPI_INT, TRACKER_RANK, FILE_INFO_TAG, MPI_COMM_WORLD);
        MPI_Send(&info.wanted_files[i].name, name_len, MPI_CHAR, TRACKER_RANK, FILE_INFO_TAG, MPI_COMM_WORLD);

        int seg_count;
        char segment[HASH_SIZE];
        MPI_Recv(&seg_count, 1, MPI_INT, TRACKER_RANK, FILE_INFO_TAG, MPI_COMM_WORLD, &status);

        for (int j = 0; j < seg_count; j++) {
            MPI_Recv(&segment, HASH_SIZE + 1, MPI_CHAR, TRACKER_RANK, FILE_INFO_TAG, MPI_COMM_WORLD, &status);
            info.wanted_files[i].wanted_segs.push_back(segment);
        }
    }
}

void get_swarm_info() {
    MPI_Status status;
    for (int i = 0; i < info.wanted_files.size(); i++) {
        int name_len = strlen(info.wanted_files[i].name);
        MPI_Send(nullptr, 0, MPI_INT, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD);
        MPI_Send(&name_len, 1, MPI_INT, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD);
        MPI_Send(&info.wanted_files[i].name, name_len, MPI_CHAR, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD);

        int member_count;
        char segment[HASH_SIZE];
        MPI_Recv(&member_count, 1, MPI_INT, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD, &status);

        for (int j = 0; j < member_count; j++) {
            int seg_count, rank;
            MPI_Recv(&rank, 1, MPI_INT, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD, &status);
            MPI_Recv(&seg_count, 1, MPI_INT, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD, &status);

            for (int k = 0; k < seg_count; k++) {
                MPI_Recv(&segment, HASH_SIZE + 1, MPI_CHAR, TRACKER_RANK, SWARM_INFO_TAG, MPI_COMM_WORLD, &status);
                info.wanted_files[i].swarm[rank].push_back(segment);
            }
        }
    }
}

int choose_peer(int file_id, int seg_id) {
    for (auto &member: info.wanted_files[file_id].swarm) {
        for (int i = 0; i < member.second.size(); i++) {
            if (member.second[i] == info.wanted_files[file_id].wanted_segs[seg_id]) {
                return member.first;
            }
        }
    }
}

void reset_received_segs() {
    int len = received_segs.size();
    MPI_Send(&len, 1, MPI_INT, TRACKER_RANK, UPDATE_TAG, MPI_COMM_WORLD);

    char filename[MAX_FILENAME];
    for (int i = 0; i < len; i++) {
        int filelen = received_segs[i].first.size();
        MPI_Send(&filelen, 1, MPI_INT, TRACKER_RANK, UPDATE_TAG, MPI_COMM_WORLD);
        strcpy(filename, received_segs[i].first.c_str());
        MPI_Send(&filename, filelen, MPI_CHAR, TRACKER_RANK, UPDATE_TAG, MPI_COMM_WORLD);
        MPI_Send(&received_segs[i].second, 1, MPI_INT, TRACKER_RANK, UPDATE_TAG, MPI_COMM_WORLD);  //seg id
    }

    received_segs.clear();
}

void renew_info() {
    MPI_Send(nullptr, 0, MPI_INT, TRACKER_RANK, UPDATE_TAG, MPI_COMM_WORLD);

    reset_received_segs();    

    get_swarm_info();
}

void send_finish_msg() {
    MPI_Send(nullptr, 0, MPI_INT, TRACKER_RANK, DOWNLOAD_DONE_TAG, MPI_COMM_WORLD);

    reset_received_segs();
}

void save_file(int rank, int file_id) {
    char outfile[MAX_FILENAME + 10];
    snprintf(outfile, MAX_FILENAME + 10, "client%d_%s", rank, info.wanted_files[file_id].name);

    ofstream fout(outfile);

    for (int i = 0; i < info.wanted_files[file_id].wanted_segs.size(); i++) {
        fout << info.wanted_files[file_id].wanted_segs[i] << endl;
    }

    fout.close();
}

void *download_thread_func(void *arg)
{
    int rank = *(int*) arg;

    MPI_Status status;

    get_file_info();
    get_swarm_info();

    int peer;  //rank 
    for (int i = 0; i < info.wanted_files.size(); i++) {
        for (int j = 0; j < info.wanted_files[i].wanted_segs.size(); j++) {
            peer = choose_peer(i, j);

            MPI_Send(nullptr, 0, MPI_INT, peer, UPLOAD_TH_TAG, MPI_COMM_WORLD);
            MPI_Send(&info.wanted_files[i].wanted_segs[j], HASH_SIZE + 1, MPI_CHAR, peer, UPLOAD_TH_TAG, MPI_COMM_WORLD);
        
            MPI_Recv(nullptr, 0, MPI_INT, peer, ACK_TAG, MPI_COMM_WORLD, &status);

            received_segs.push_back(make_pair(info.wanted_files[i].name, j));
            if (received_segs.size() == 10) {
                renew_info();
            }
        }

        save_file(rank, i);
        renew_info();
    }

    send_finish_msg();
    return NULL;
}

void *upload_thread_func(void *arg)
{
    int rank = *(int*) arg;

    bool finished = false;
    MPI_Status status;
    char segment[HASH_SIZE];
    int peer;

    while (!finished) {
        MPI_Recv(nullptr, 0, MPI_INT, MPI_ANY_SOURCE, UPLOAD_TH_TAG, MPI_COMM_WORLD, &status);

        switch (status.MPI_SOURCE) {
            case TRACKER_RANK:
                return NULL;
                break;
            default:
                peer = status.MPI_SOURCE;
                MPI_Recv(&segment, HASH_SIZE + 1, MPI_CHAR, peer, UPLOAD_TH_TAG, MPI_COMM_WORLD, &status);
                MPI_Send(nullptr, 0, MPI_INT, peer, ACK_TAG, MPI_COMM_WORLD);
                break;
        }
    }

    return NULL;
}


bool is_in_database(string filename) {
    return db.find(filename) != db.end();
}

void init_tracker(int numtasks) {
    int file_count;
    MPI_Status status;
    for (int i = 1; i < numtasks; i++) {
        MPI_Recv(&file_count, 1, MPI_INT, i, INIT_TAG, MPI_COMM_WORLD, &status);
        
        for (int j = 0; j < file_count; j++) {
            int len, seg_count;
            char filename[MAX_FILENAME], segment[HASH_SIZE];
            MPI_Recv(&len, 1, MPI_INT, i, INIT_TAG, MPI_COMM_WORLD, &status);
            MPI_Recv(&filename, len, MPI_CHAR, i, INIT_TAG, MPI_COMM_WORLD, &status);
            MPI_Recv(&seg_count, 1, MPI_INT, i, INIT_TAG, MPI_COMM_WORLD, &status);

            bool already_saved = is_in_database(filename);
            for (int j = 0; j < seg_count; j++) {
                MPI_Recv(&segment, HASH_SIZE + 1, MPI_CHAR, i, INIT_TAG, MPI_COMM_WORLD, &status);
                if (!already_saved) {
                    db[filename].first.push_back(segment);
                }
                db[filename].second[i].push_back(segment);
            }
        }
    }
}


void send_file_info(int rank) {
    MPI_Status status;
    int name_len;
    char filename[MAX_FILENAME];
    char hash[HASH_SIZE];
    MPI_Recv(&name_len, 1, MPI_INT, rank, FILE_INFO_TAG, MPI_COMM_WORLD, &status);
    MPI_Recv(&filename, name_len, MPI_CHAR, rank, FILE_INFO_TAG, MPI_COMM_WORLD, &status);

    int len = db[filename].first.size();
    MPI_Send(&len, 1, MPI_INT, rank, FILE_INFO_TAG, MPI_COMM_WORLD);
    for (int i = 0; i < len; i++) {
        strcpy(hash, db[filename].first[i].c_str());
        MPI_Send(&hash, HASH_SIZE + 1, MPI_CHAR, rank, FILE_INFO_TAG, MPI_COMM_WORLD);
    }
}

void send_swarm_info(int rank) {
    MPI_Status status;
    int name_len;
    char filename[MAX_FILENAME];
    char hash[HASH_SIZE];
    MPI_Recv(&name_len, 1, MPI_INT, rank, SWARM_INFO_TAG, MPI_COMM_WORLD, &status);
    MPI_Recv(&filename, name_len, MPI_CHAR, rank, SWARM_INFO_TAG, MPI_COMM_WORLD, &status);

    int member_count = db[filename].second.size();
    int len;
    MPI_Send(&member_count, 1, MPI_INT, rank, SWARM_INFO_TAG, MPI_COMM_WORLD);
    for (auto &member: db[filename].second) {
        len = member.second.size();
        MPI_Send(&member.first, 1, MPI_INT, rank, SWARM_INFO_TAG, MPI_COMM_WORLD);
        MPI_Send(&len, 1, MPI_INT, rank, SWARM_INFO_TAG, MPI_COMM_WORLD);
        for (int j = 0; j < member.second.size(); j++) {
            strcpy(hash, member.second[j].c_str());
            MPI_Send(&hash, HASH_SIZE + 1, MPI_CHAR, rank, SWARM_INFO_TAG, MPI_COMM_WORLD);
        }
    }
}

void update_info(int rank) {
    MPI_Status status;
    int len;
    MPI_Recv(&len, 1, MPI_INT, rank, UPDATE_TAG, MPI_COMM_WORLD, &status);

    for (int i = 0; i < len; i++) {
        int filelen, seg_id;
        char filename[MAX_FILENAME];
        MPI_Recv(&filelen, 1, MPI_INT, rank, UPDATE_TAG, MPI_COMM_WORLD, &status);
        MPI_Recv(&filename, filelen, MPI_CHAR, rank, UPDATE_TAG, MPI_COMM_WORLD, &status);
        MPI_Recv(&seg_id, 1, MPI_INT, rank, UPDATE_TAG, MPI_COMM_WORLD, &status);

        db[filename].second[rank].push_back(db[filename].first[seg_id]);
    }
}


void tracker(int numtasks, int rank) {
    init_tracker(numtasks);

    int ok = 1;
    MPI_Bcast(&ok, 1, MPI_INT, TRACKER_RANK, MPI_COMM_WORLD);

    int finished = 0;
    MPI_Status status;
    while (finished < numtasks - 1) {
        MPI_Recv(nullptr, 0, MPI_INT, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        
        switch (status.MPI_TAG) {
            case FILE_INFO_TAG:  // ask for file info
                send_file_info(status.MPI_SOURCE);
                break;
            case SWARM_INFO_TAG:  // ask for swarm info
                send_swarm_info(status.MPI_SOURCE);
                break;
            case UPDATE_TAG:
                update_info(status.MPI_SOURCE);
                break;
            case DOWNLOAD_DONE_TAG: // done downloading
                update_info(status.MPI_SOURCE);
                finished++;
                break;
        }
    }

    for (int i = 1; i < numtasks; i++) {
        MPI_Send(nullptr, 0, MPI_INT, i, UPLOAD_TH_TAG, MPI_COMM_WORLD);
    }
}


void init_peer(int rank) {
    char in_filename[MAX_FILENAME];
    snprintf(in_filename, MAX_FILENAME, "in%d.txt", rank);

    ifstream fin(in_filename);

    int owned_file_count;
    fin >> owned_file_count;

    MPI_Send(&owned_file_count, 1, MPI_INT, TRACKER_RANK, INIT_TAG, MPI_COMM_WORLD);

    int seg_count;
    char segment[HASH_SIZE];
    for (int i = 0; i < owned_file_count; i++) {
        file new_file;

        fin >> new_file.name >> seg_count;

        int name_len = strlen(new_file.name);
        MPI_Send(&name_len, 1, MPI_INT, TRACKER_RANK, INIT_TAG, MPI_COMM_WORLD);
        MPI_Send(&new_file.name, name_len, MPI_CHAR, TRACKER_RANK, INIT_TAG, MPI_COMM_WORLD);
        
        MPI_Send(&seg_count, 1, MPI_INT, TRACKER_RANK, INIT_TAG, MPI_COMM_WORLD);
        for (int j = 0; j < seg_count; j++) {
            fin >> segment;
            new_file.segments.push_back(segment);

            MPI_Send(&segment, HASH_SIZE + 1, MPI_CHAR, TRACKER_RANK, INIT_TAG, MPI_COMM_WORLD);
        }

        info.owned_files.push_back(new_file);
    }

    int wanted_file_count;
    fin >> wanted_file_count;
    for (int i = 0; i < wanted_file_count; i++) {
        wanted_file new_wanted_file;
        fin >> new_wanted_file.name;
        info.wanted_files.push_back(new_wanted_file);
    }

    fin.close();
}

void peer(int numtasks, int rank) {
    pthread_t download_thread;
    pthread_t upload_thread;
    void *status;
    int r;

    init_peer(rank);

    int ok;
    MPI_Bcast(&ok, 1, MPI_INT, TRACKER_RANK, MPI_COMM_WORLD);

    r = pthread_create(&download_thread, NULL, download_thread_func, (void *) &rank);
    if (r) {
        printf("Eroare la crearea thread-ului de download\n");
        exit(-1);
    }

    r = pthread_create(&upload_thread, NULL, upload_thread_func, (void *) &rank);
    if (r) {
        printf("Eroare la crearea thread-ului de upload\n");
        exit(-1);
    }

    r = pthread_join(download_thread, &status);
    if (r) {
        printf("Eroare la asteptarea thread-ului de download\n");
        exit(-1);
    }

    r = pthread_join(upload_thread, &status);
    if (r) {
        printf("Eroare la asteptarea thread-ului de upload\n");
        exit(-1);
    }
}
 
int main (int argc, char *argv[]) {
    int numtasks, rank;
 
    int provided;
    MPI_Init_thread(&argc, &argv, MPI_THREAD_MULTIPLE, &provided);
    if (provided < MPI_THREAD_MULTIPLE) {
        fprintf(stderr, "MPI nu are suport pentru multi-threading\n");
        exit(-1);
    }
    MPI_Comm_size(MPI_COMM_WORLD, &numtasks);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    if (rank == TRACKER_RANK) {
        tracker(numtasks, rank);
    } else {
        peer(numtasks, rank);
    }

    MPI_Finalize();
}
